#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
    __author__ = "Georges Nassopoulos"
    __copyright__ = None
    __version__ = "0.0.9"
    __email__ = "georges.nassopoulos@gmail.com"
    __status__ = "Dev"
    __desc__ = "Execution multithreadee des requetes curl (mode synchrone ou asynchrone)."
'''

import time
import subprocess
import sys
from multiprocessing import Pool

def read_commands():
    """
        Lit les commandes depuis requests.txt et les retourne sous forme de liste.
    """
    with open("requests.txt", "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def execute_command(cmd):
    """
        Exécute une commande curl et mesure le temps d'exécution.
        Retourne : (temps écoulé, sortie texte)
    """
    t0 = time.time()
    result = subprocess.run(cmd.split(), capture_output=True, text=True)
    t1 = time.time()
    return (t1 - t0, result.stdout.strip())

def wrapper_with_commands(args):
    """
        Enveloppe l'appel a execute_command avec un index et la liste des commandes.
    """
    
    index, commands = args
    cmd = commands[index % len(commands)]
    return execute_command(cmd)

def overflow_requests(mode="sync", parallelism=5):
    """
        Execute plusieurs requêtes curl en parallele, de facon synchrone ou asynchrone.
        
        Parametres :
        - mode : "sync" ou "async" (symbolique ici, le comportement est identique)
        - parallelism : nombre de requetes a envoyer en parallele
    """
    
    commands = read_commands()
    if not commands:
        print("Aucune commande trouvée dans requests.txt")
        return

    args = [(i, commands) for i in range(parallelism)]

    with Pool(parallelism) as pool:
        results = pool.map(wrapper_with_commands, args)

    for idx, (delta, output) in enumerate(results):
        print(f"--- Requête {idx + 1} ---")
        print(f"Temps de réponse : {delta:.3f}s")
        print(output)
        print()

if __name__ == '__main__':

    mode = sys.argv[1] if len(sys.argv) > 1 else "sync"
    parallelism = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    overflow_requests(mode, parallelism)
