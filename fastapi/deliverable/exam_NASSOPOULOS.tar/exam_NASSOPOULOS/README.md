# fastapi_exam_NASSOPOULOS

## Table of contents

- [Getting Started](#getting-started)
- [Requirements](#requirements)
- [Installing](#installing)
- [Usage](#usage)
- [Errors and Exceptions](#errors-and-exceptions)
- [Project Structure](#project-structure)
- [Author](#author)

---

## Getting Started

Ce projet fournit une API FastAPI pour la génération de QCM à partir d'un fichier CSV, accompagnée de scripts de test, d’analyse exploratoire et de validation en multithread.

---

## Requirements

- Python ≥ 3.8
- spaCy + modèle français `fr_core_news_sm`

---

## Installing

```bash
pip3 install -r requirements.txt
python3 -m spacy download fr_core_news_sm
```

---

## Usage

```bash
chmod +x setup.sh
./setup.sh
```

Vous pourrez :
- Lancer l’analyse exploratoire (`EDA`)
- Tester les requêtes via curl en mode synchrone ou asynchrone
- Saisir une commande manuellement

---

## Errors and Exceptions

- `401` → Authentification invalide
- `403` → Accès refusé (admin)
- `404` → Questions introuvables
- `422` → Données invalides (FastAPI)

---

## Project Structure

.
├── __init__.py
├── questions.csv
├── main.py                   → API FastAPI avec endpoints et gestion des erreurs
├── test.py                   → Script d’exécution des requêtes curl
├── multithreading.py         → Exécution parallèle (sync / async) des requêtes
├── eda_questions.py          → Analyse exploratoire et graphiques (EDA)
├── eda_plots/                → Histogrammes, pie charts, wordclouds générés
├── results/                  → resulutats des requêtes requests.txt (pour le moment sycrhones)
├── requests.txt              → Liste de requêtes curl à exécuter
├── requirements.txt          → Dépendances du projet
├── setup.sh                  → Script interactif pour tout lancer
├── optional_archi.txt        → Documentation alternative
└── README.md                 → Ce fichier

---

## Author

Georges Nassopoulos  
��� georges.nassopoulos@gmail.com

