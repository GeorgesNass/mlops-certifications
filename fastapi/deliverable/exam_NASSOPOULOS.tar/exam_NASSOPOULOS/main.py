#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
    __author__ = "Georges Nassopoulos"
    __copyright__ = None
    __version__ = "0.0.9"
    __email__ = "georges.nassopoulos@gmail.com"
    __status__ = "Dev"
    __desc__ = "Serveur FastAPI avec gestion complete d'erreurs personnalisees, y compris l'erreur 401 non autorisee."
'''

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from pydantic import BaseModel
from typing import List
import pandas as pd
import random
import secrets
import datetime

## Creation de l'application FastAPI
app = FastAPI()

## Authentification de base
security = HTTPBasic()
users = {
    "alice": "wonderland",
    "bob": "builder",
    "clementine": "mandarine"
}

## Chargement des questions
df = pd.read_csv("questions.csv")
questions = df.to_dict(orient="records")
#print(questions)

## Modele Pydantic pour la route /generate_quiz
class QuizRequest(BaseModel):
    test_type: str
    categories: List[str]
    number_of_questions: int

## Gestion des exceptions personnalisees
class MyException(Exception):
    def __init__(self, name: str, date: str):
        self.name = name
        self.date = date

class BadIndexException(Exception):
    def __init__(self, request: Request):
        self.request = request
        self.name = "Invalid Index"
        self.date = str(datetime.datetime.now())

class InvalidIndexTypeException(Exception):
    def __init__(self, request: Request):
        self.request = request
        self.name = "Invalid Type"
        self.date = str(datetime.datetime.now())

class UnauthorizedAccessException(Exception):
    def __init__(self, request: Request):
        self.request = request
        self.name = "Unauthorized"
        self.date = str(datetime.datetime.now())

@app.exception_handler(MyException)
async def handle_my_exception(request: Request, exc: MyException):
    return JSONResponse(
        status_code=418,
        content={
            "url": str(request.url),
            "name": exc.name,
            "message": "Erreur personnalisee generee intentionnellement.",
            "date": exc.date
        }
    )

@app.exception_handler(BadIndexException)
async def handle_bad_index(request: Request, exc: BadIndexException):
    return JSONResponse(
        status_code=404,
        content={
            "url": str(request.url),
            "name": exc.name,
            "message": "Index invalide pour acceder a une ressource.",
            "date": exc.date
        }
    )

@app.exception_handler(InvalidIndexTypeException)
async def handle_invalid_type(request: Request, exc: InvalidIndexTypeException):
    return JSONResponse(
        status_code=400,
        content={
            "url": str(request.url),
            "name": exc.name,
            "message": "Type d'index non valide (ex: un entier etait attendu).",
            "date": exc.date
        }
    )

@app.exception_handler(UnauthorizedAccessException)
async def handle_unauthorized(request: Request, exc: UnauthorizedAccessException):
    return JSONResponse(
        status_code=401,
        content={
            "url": str(request.url),
            "name": exc.name,
            "message": "Acces non autorise. Veuillez vous authentifier.",
            "date": exc.date
        }
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={"error": exc.errors(), "message": "Erreur de validation des donnees."}
    )

@app.exception_handler(StarletteHTTPException)
async def starlette_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "message": f"Erreur HTTP detectee a {datetime.datetime.now().isoformat()}"
        }
    )

# Authentification utilisateur
def authenticate(
    request: Request,
    credentials: HTTPBasicCredentials = Depends(security)
):
    correct_password = users.get(credentials.username)
    if not correct_password or not secrets.compare_digest(credentials.password, correct_password):
        raise UnauthorizedAccessException(request)
    return credentials.username

## ROUTES
@app.get("/verify")
def verify():
    """Verifie que l'API est fonctionnelle."""
    
    return {"message": "L'API est fonctionnelle."}

@app.post("/generate_quiz")
def generate_quiz(payload: QuizRequest, user: str = Depends(authenticate)):
    try:
        filtered = [
            q for q in questions
            if (q.get("use") or "").strip().lower() == payload.test_type.strip().lower()
            and (q.get("subject") or "").strip().lower() in [cat.strip().lower() for cat in payload.categories]
        ]

        if not filtered:
            raise HTTPException(status_code=404, detail={
                "error": "Aucune question trouvee.",
                "message": f"Erreur HTTP detectee a {datetime.datetime.now().isoformat()}"
            })

        random.shuffle(filtered)  # Melange des questions pour ordre aleatoire
        selected = filtered[:payload.number_of_questions]

        formatted = [
            {
                "question": q["question"],
                "propositions": {
                    k[-1]: q[k] for k in q if k.startswith("response") and pd.notna(q[k])
                },
                "reponse": q["correct"]
            }
            for q in selected
        ]

        return {"quiz": formatted}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/create_question")
def create_question(new_question: dict):
    """Permet a l'administrateur de creer une nouvelle question."""
    
    if new_question.get("admin_username") != "admin" or new_question.get("admin_password") != "4dm1N":
        raise HTTPException(status_code=403, detail="Acces refuse.")

    cleaned_question = {k: v for k, v in new_question.items() if k not in ["admin_username", "admin_password"]}
    questions.append(cleaned_question)
    df_updated = pd.DataFrame(questions)
    df_updated.to_csv("questions.csv", index=False)

    return {"message": "Question creee avec succes et sauvegardee dans questions.csv."}

