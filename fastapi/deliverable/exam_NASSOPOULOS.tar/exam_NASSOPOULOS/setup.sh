#!/bin/bash

echo "=================================================="
echo "Script de demarrage de l'API FastAPI"
echo "=================================================="
echo "Conseil : il est fortement recommande d'executer ce script dans un environnement virtuel (virtualenv/venv)"
echo ""

## Demande a l'utilisateur s'il souhaite installer les dependances
echo "Souhaitez-vous installer les dependances ? (OUI/NON) [O/n]"
read reponse
reponse=$(echo "$reponse" | tr '[:upper:]' '[:lower:]')

if [[ "$reponse" == "oui" || "$reponse" == "o" || "$reponse" == "yes" || "$reponse" == "y" ]]; then
    echo "Installation des dependances..."
    pip3 install -r requirements.txt
    echo "Forcage de la version pydantic compatible..."
    pip3 install pydantic==1.10.13
    echo "Telechargement du modele spaCy FR..."
    python3 -m spacy download fr_core_news_sm
else
    echo "Installation des dependances ignoree."
fi

## Verifie si un processus utilise deja le port 8000
pids=$(lsof -ti:8000)
if [ -n "$pids" ]; then
    echo ""
    echo "Un processus FastAPI utilise deja le port 8000 (PID: $pids)."
    echo "Voulez-vous le terminer ? (OUI/NON) [O/n]"
    read tuer
    tuer=$(echo "$tuer" | tr '[:upper:]' '[:lower:]')

    if [[ "$tuer" == "oui" || "$tuer" == "o" || "$tuer" == "yes" || "$tuer" == "y" ]]; then
        kill $pids
        sleep 2
        echo "Ancien processus termine."
    else
        echo "Impossible de lancer un nouveau serveur sur le port 8000. Utilisation de l'api existante"
    fi
	## Re lancement du serveur FastAPI en arrière-plan
	echo ""
	echo "Lancement du serveur FastAPI avec uvicorn (en arriere-plan)..."
	nohup python3 -m uvicorn main:app --reload > uvicorn.log 2>&1 &
	sleep 5
	echo "Serveur lance sur http://127.0.0.1:8000"
else
	## Lancement du serveur FastAPI en arrière-plan
	echo ""
	echo "Lancement du serveur FastAPI avec uvicorn (en arriere-plan)..."
	nohup python3 -m uvicorn main:app --reload > uvicorn.log 2>&1 &
	sleep 5
	echo "Serveur lance sur http://127.0.0.1:8000"
fi



## Boucle de menu
while true; do
    echo ""
    echo ""
    echo "----------------------------------------------------------------------"
    echo "Veuillez choisir une option (ou tapez 'exit' pour quitter) :"
    echo "1. Exploratory Data Analysis"
    echo "2. Executer les requetes curl en mode multithread synchrone"
    #echo "3. Executer les requetes curl en mode multithread asynchrone"
    echo "3. Saisir une requete curl personnalisee"
    read option

    num_lines=$(grep -cve '^\s*$' requests.txt)
    mapfile -t lines < <(grep -ve '^\s*$' requests.txt)
    mkdir -p results

    if [[ "$option" == "1" ]]; then
        echo "Analyse exploratoire des questions..."
        python3 eda_questions.py

	elif [[ "$option" == "2" ]]; then
		echo "Execution en mode multithread synchrone ($num_lines requetes)..."
		rm -f results/responses_synchrone.txt
		for ((i = 0; i < num_lines; i++)); do
			echo -e "\n--- Requete $((i+1)) ---" >> results/responses_synchrone.txt
			eval "${lines[$i]}" -s >> results/responses_synchrone.txt 2>&1
		done
		echo "Resultats enregistres dans : results/responses_synchrone.txt"
		
	# elif [[ "$option" == "3" ]]; then
		# echo "Execution en mode multithread asynchrone ($num_lines requetes)..."
		# mkdir -p tmp_async_responses
		# rm -f tmp_async_responses/req_*.txt results/responses_asynchrone.txt

		# for ((i = 0; i < num_lines; i++)); do
			# (
				# echo -e "--- Requete $((i + 1)) ---" > tmp_async_responses/req_$i.txt
				# eval "${lines[$i]/curl /curl -s }" >> tmp_async_responses/req_$i.txt 2>&1
			# ) &
		# done

		# wait

		# # Recombiner dans l'ordre
		# for ((i = 0; i < num_lines; i++)); do
			# cat tmp_async_responses/req_$i.txt >> results/responses_asynchrone.txt
			# echo -e "\n" >> results/responses_asynchrone.txt
		# done

		# rm -rf tmp_async_responses
		# echo "Resultats enregistres dans : results/responses_asynchrone.txt"

    elif [[ "$option" == "3" ]]; then
        echo "Entrez votre commande curl complete :"
        read curl_cmd
        echo -e "\n===== Resultat de la requete personnalisee ====="
        eval "$curl_cmd"

    elif [[ "$option" == "exit" ]]; then
        echo "Fermeture du script."
        break
    else
        echo "Option invalide. Veuillez reessayer."
    fi
done
