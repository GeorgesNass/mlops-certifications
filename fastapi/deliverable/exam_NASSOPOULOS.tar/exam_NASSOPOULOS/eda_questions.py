#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
    __author__ = "Georges Nassopoulos"
    __copyright__ = None
    __version__ = "0.0.9"
    __email__ = "georges.nassopoulos@gmail.com"
    __status__ = "Dev"
    __desc__ = "Exploratory Data Analysis avec statistiques descriptives et visualisations (wordcloud nettoye, pie chart, histogramme)."
'''

import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import spacy
import os
from collections import Counter

def run_eda():
    """
        Effectue une analyse exploratoire :
        - Affiche des stats simples
        - Cree trois visualisations dans eda_plots/
    """
    
    df = pd.read_csv("questions.csv")

    ## Chargement du modele français de spaCy
    try:
        nlp = spacy.load("fr_core_news_sm")
    except:
        print("Le modele 'fr_core_news_sm' n'est pas installe. Veuillez l'installer avec : python3 -m spacy download fr_core_news_sm")
        return

    stopwords = nlp.Defaults.stop_words

    ## Creation du dossier pour les graphiques
    os.makedirs("eda_plots", exist_ok=True)

    ## Statistiques generales
    print("Nombre de questions :", len(df))
    print("\nRepartition des sujets :")
    print(df["subject"].value_counts())
    print("\nRepartition des types de test :")
    print(df["use"].value_counts())

    ## Histogramme du nombre de reponses disponibles
    df["nb_reponses"] = df[["responseA", "responseB", "responseC", "responseD"]].notna().sum(axis=1)

    plt.figure()
    df["nb_reponses"].value_counts().sort_index().plot(kind="bar", color="skyblue")
    plt.title("Nombre de reponses par question")
    plt.xlabel("Nombre de reponses disponibles")
    plt.ylabel("Nombre de questions")
    plt.tight_layout()
    plt.savefig("eda_plots/histogram_reponses.png")

    ## Pie chart des sujets
    plt.figure()
    df["subject"].value_counts().plot(kind="pie", autopct="%1.1f%%")
    plt.title("Repartition des sujets")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig("eda_plots/pie_subjects.png")

    ## Word cloud des questions, filtre par minumum 3 occurences
    text = " ".join(df["question"].dropna().astype(str)).lower()
    tokens = [t.text for t in nlp(text) if t.is_alpha and t.text not in stopwords]
    freq = Counter(tokens)
    freq_filtered = {word: count for word, count in freq.items() if count >= 3}

    if freq_filtered:
        wc = WordCloud(width=800, height=400, background_color="white").generate_from_frequencies(freq_filtered)
        plt.figure(figsize=(10, 5))
        plt.imshow(wc, interpolation="bilinear")
        plt.axis("off")
        plt.title("Nuage de mots des questions (mots frequents uniquement)")
        plt.tight_layout()
        plt.savefig("eda_plots/wordcloud_questions.png")
        print("\n Graphiques sauvegardes dans eda_plots/")
    else:
        print("\n Pas assez de mots frequents pour generer le nuage de mots.")

if __name__ == "__main__":
    run_eda()

