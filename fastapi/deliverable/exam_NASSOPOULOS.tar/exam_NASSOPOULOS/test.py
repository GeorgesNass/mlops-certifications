#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
    __author__ = "Georges Nassopoulos"
    __copyright__ = None
    __version__ = "0.0.9"
    __email__ = "georges.nassopoulos@gmail.com"
    __status__ = "Dev"
    __desc__ = "Script d'execution des requetes curl (automatique ou manuelle) pour tester l'API."
'''

import subprocess
import os

def execute_from_file():
    """
        Execute toutes les requetes contenues dans requests.txt
        et enregistre les reponses dans results/responses.txt
    """
    
    with open("requests.txt", "r", encoding="utf-8") as f:
        requests = [line.strip() for line in f if line.strip()]
    
    os.makedirs("results", exist_ok=True)
    with open("results/responses.txt", "w", encoding="utf-8") as out:
        for i, cmd in enumerate(requests):
            out.write(f"===== Requete {i+1} =====\n")
            out.write(f"Commande : {cmd}\n")
            out.write("---------------------------\n")
            try:
                result = subprocess.run(cmd.split(), capture_output=True, text=True)
                out.write(result.stdout + "\n")
            except Exception as e:
                out.write(f"Erreur d'execution : {str(e)}\n")
            out.write("\n")

def execute_custom():
    """
        Permet a l'utilisateur de saisir une commande curl
        et enregistre le resultat dans results/responses.txt
    """
    
    cmd = input("Entrez votre commande curl complete :\n")
    os.makedirs("results", exist_ok=True)
    with open("results/responses.txt", "w", encoding="utf-8") as out:
        out.write("===== Requete manuelle =====\n")
        out.write(f"{cmd}\n")
        try:
            result = subprocess.run(cmd.split(), capture_output=True, text=True)
            out.write(result.stdout + "\n")
        except Exception as e:
            out.write(f"Erreur d'execution : {str(e)}\n")

if __name__ == "__main__":

    print("1. Executer tous les exemples depuis requests.txt")
    print("2. Entrer une commande curl personnalisee")
    choix = input("Choix (1/2) : ").strip()

    if choix == "1":
        execute_from_file()
    elif choix == "2":
        execute_custom()
    else:
        print("Choix invalide.")

