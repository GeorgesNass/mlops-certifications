#!/bin/bash

## Fonction qui interroge l'API pour les cartes graphiques dans le enonce du examen et enregistre leur ventes
collect_data() {
    ## Ajout de la date du scraping
    date >> /home/ubuntu/exam_NASSOPOULOS/exam_bash/sales.txt

    ## Liste des cartes a interroger
    cartes="rtx3060 rtx3070 rtx3080 rtx3090 rx6700"

    ## Boucle sur chaque carte pour recuperer les ventes via l'API
    for carte in $cartes; do
        nb_ventes=$(curl -s http://0.0.0.0:5000/$carte)
        echo "$carte:$nb_ventes" >> /home/ubuntu/exam_NASSOPOULOS/exam_bash/sales.txt
    done

    ## Ligne vide pour séparer les blocs
    echo "" >> /home/ubuntu/exam_NASSOPOULOS/exam_bash/sales.txt
}

## Appel de la fonction
collect_data

