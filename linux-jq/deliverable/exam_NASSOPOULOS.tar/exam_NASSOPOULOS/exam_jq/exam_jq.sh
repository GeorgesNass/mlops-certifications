#!/bin/bash

echo "1. Nombre de attributs par document + attribut name (12 premiers)"
jq '.[] | {name, total_fields: (keys | length)}' people.json | head -n 12
echo "Commande : jq '.[] | {name, total_fields: (keys | length)}' people.json | head -n 12"
echo "Réponse : Chaque document possède 17 attributs, comme observé dans la sortie."
echo -e "\n---------------------------------\n"

echo "2. Nombre de valeurs \"unknown\" pour l'attribut birth_year"
jq '[.[] | select(.birth_year == "unknown")] | length' people.json | tail -n 1
echo "Commande : jq '[.[] | select(.birth_year == \"unknown\")] | length' people.json | tail -n 1"
echo "Réponse : Il y a exactement 42 personnages dont l'année de naissance est 'unknown'."
echo -e "\n---------------------------------\n"

echo "3. Date de creation (format YYYY-MM-DD) et nom (10 premieres lignes)"
jq '.[] | {name, creation_date: (.created | split("T")[0])}' people.json | head -n 10
echo "Commande : jq '.[] | {name, creation_date: (.created | split(\"T\")[0])}' people.json | head -n 10"
echo -e "\n---------------------------------\n"

echo "4. Paires d’IDs des personnages nes en meme temps"
jq '[ group_by(.birth_year)[] | select(length == 2) | map(.url | capture("people/(?<id>[0-9]+)").id) ]' people.json
echo "Commande : jq '[ group_by(.birth_year)[] | select(length == 2) | map(.url | capture(\"people/(?<id>[0-9]+)\").id) ]' people.json"
echo "Réponse : Plusieurs paires ont la même birth_year. Ici, on observe 6 paires."
echo -e "\n---------------------------------\n"

echo "5. Premier film de chaque personnage avec son nom (10 premieres lignes)"
jq '.[] | try {name, first_film: (.films[0])} catch {name, first_film: "non_disponible"}' people.json | head -n 10
echo "Commande : jq '.[] | try {name, first_film: (.films[0])} catch {name, first_film: \"non_disponible\"}' people.json | head -n 10"
echo -e "\n---------------------------------\n"


echo -e "\n----------------BONUS----------------\n"

mkdir -p bonus

# Bonus 6 – Supprimer les documents ou height n’est pas un nombre
jq '[.[] | if (.height | test("^[0-9]+$")) then . else empty end]' people.json > bonus/people_6.json

# Bonus 7 – Transformer height en entier
jq '[.[] | select(.height | test("^[0-9]+$")) | .height |= tonumber]' people.json > bonus/people_7.json

# Bonus 8 – Personnages entre 156 et 171 cm
jq '[.[] | select(.height | test("^[0-9]+$")) | .height |= tonumber | select(.height >= 156 and .height <= 171)]' people.json > bonus/people_8.json

# Bonus 9 – Plus petit individu parmi ceux entre 156 et 171
jq -r 'min_by(.height) | "\(.name) is \(.height) tall"' bonus/people_8.json > bonus/people_9.txt

