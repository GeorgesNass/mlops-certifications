import os
import requests

API_URL = "http://api-sentiment:8000"

def log(message):
    if os.environ.get("LOG") == "1":
        with open("/logs/api_test.log", "a") as f:
            f.write(message)

def run_sentiment_test(endpoint, username, password, sentence, expected_sign):
    response = requests.get(
        f"{API_URL}/{endpoint}",
        params={
            "username": username,
            "password": password,
            "sentence": sentence
        }
    )

    try:
        result = response.json()
        score = result.get("score", 0)
    except Exception:
        score = None

    if expected_sign == "positive":
        test_status = "SUCCESS" if score and score > 0 else "FAILURE"
    elif expected_sign == "negative":
        test_status = "SUCCESS" if score and score < 0 else "FAILURE"
    else:
        test_status = "FAILURE"

    output = f"""
============================
      Content test
============================

Request done at "/{endpoint}"
| username="{username}"
| password="{password}"
| sentence="{sentence}"

Expected sentiment = {expected_sign}
Returned score     = {score}

==> {test_status}

"""
    print(output)
    log(output)

if __name__ == "__main__":
    ## Test de deux phrases, positive et negative, avec Bob pour V1
    run_sentiment_test("v1/sentiment", "bob", "builder", "life is beautiful", "positive")
    run_sentiment_test("v1/sentiment", "bob", "builder", "that sucks", "negative")

    ## Test de deux phrases, positive et negative, avec Alice pour V2 car que elle a acces
    run_sentiment_test("v2/sentiment", "alice", "wonderland", "life is beautiful", "positive")
    run_sentiment_test("v2/sentiment", "alice", "wonderland", "that sucks", "negative")

