import os
import requests

API_URL = "http://api-sentiment:8000"

def log(message):
    if os.environ.get("LOG") == "1":
        with open("/logs/api_test.log", "a") as f:
            f.write(message)

def run_test(username, password, expected_status):
    response = requests.get(
        f"{API_URL}/permissions",
        params={"username": username, "password": password}
    )
    status_code = response.status_code
    test_status = "SUCCESS" if status_code == expected_status else "FAILURE"

    output = f"""
============================
    Authentication test
============================

Request done at "/permissions"
| username="{username}"
| password="{password}"

Expected result = {expected_status}
Actual result   = {status_code}

==> {test_status}

"""
    print(output)
    log(output)

if __name__ == "__main__":
    run_test("alice", "wonderland", 200)
    run_test("bob", "builder", 200)
    run_test("clementine", "mandarine", 403)

