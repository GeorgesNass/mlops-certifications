#!/usr/bin/env bash
## Load test script for the Accident Prediction API
## Mixes valid and invalid requests, then fetches /metrics
## Usage: ./load_test.sh

set -euo pipefail

## Configuration
API_URL="http://localhost:8000"
PREDICT_ENDPOINT="$API_URL/predict/"
PROMETHEUS_METRICS="$API_URL/metrics"
ITERATIONS=40   ## total number of attempts (mixing valid + invalid)
SLEEP_BETWEEN=0.05  ## seconds between requests (small gap)

## Define some valid payloads (these match your Accident model)
valid_payloads=(
'{"place":1,"catu":1,"sexe":1,"secu1":2.0,"year_acc":2021,"victim_age":42,"catv":2,"obsm":0,"motor":1,"catr":3,"circ":3,"surf":1,"situ":1,"vma":90,"jour":29,"mois":11,"lum":4,"dep":80,"com":80131,"agg_":1,"int_":1,"atm":0,"col":7,"lat":49.8516,"long":2.4042,"hour":21,"nb_victim":1,"nb_vehicules":1}'
'{"place":10,"catu":3,"sexe":2,"secu1":0.0,"year_acc":2021,"victim_age":19,"catv":2,"obsm":1,"motor":1,"catr":4,"circ":2,"surf":1,"situ":1,"vma":30,"jour":4,"mois":11,"lum":5,"dep":59,"com":59350,"agg_":2,"int_":2,"atm":0,"col":6,"lat":50.6325934047,"long":3.0522062542,"hour":22,"nb_victim":4,"nb_vehicules":1}'
'{"place":1,"catu":1,"sexe":1,"secu1":2.0,"year_acc":2021,"victim_age":78,"catv":1,"obsm":2,"motor":1,"catr":3,"circ":1,"surf":1,"situ":1,"vma":50,"jour":8,"mois":7,"lum":1,"dep":58,"com":58194,"agg_":2,"int_":4,"atm":0,"col":2,"lat":46.9885,"long":3.1663,"hour":8,"nb_victim":2,"nb_vehicules":2}'
)

## Define invalid payloads to trigger validation errors
invalid_payloads=(
## wrong type for an integer field -> should return 422
'{"place":1,"catu":1,"sexe":"oops","secu1":2.0,"year_acc":2021,"victim_age":42}'
## missing many required fields -> 422
'{"invalid_field":123,"catu":1,"sexe":1}'
## wrong type for numeric field -> 422
'{"place":1,"catu":1,"sexe":1,"secu1":2.0,"year_acc":2021,"victim_age":"notanumber","catv":2,"obsm":0,"motor":1,"catr":3,"circ":3,"surf":1,"situ":1,"vma":90,"jour":29,"mois":11,"lum":4,"dep":80,"com":80131,"agg_":1,"int_":1,"atm":0,"col":7,"lat":49.8516,"long":2.4042,"hour":21,"nb_victim":1,"nb_vehicules":1}'
)

## Helper function: send a POST and print status code and a short prefix of response
send_post() {
  local payload="$1"
  ## -s silent, -S show error, -o /dev/null to suppress body, -w to print status
  ## we also capture body once for small debug if needed
  http_code=$(curl -s -o /tmp/last_response_body.txt -w "%{http_code}" \
    -X POST "$PREDICT_ENDPOINT" -H "Content-Type: application/json" -d "$payload" || true)
  echo "POST $PREDICT_ENDPOINT -> ${http_code}"
  ## Print short preview of body (first 300 chars) for debugging
  head -c 300 /tmp/last_response_body.txt | sed -n '1,3p'
  echo
}

## Helper function: send a GET and print status
send_get() {
  local path="$1"
  http_code=$(curl -s -o /tmp/last_response_body.txt -w "%{http_code}" "$path" || true)
  echo "GET $path -> ${http_code}"
  head -c 300 /tmp/last_response_body.txt | sed -n '1,3p'
  echo
}

echo "Starting mixed load: ${ITERATIONS} requests (valid + invalid + misc)."
echo "API endpoint: $PREDICT_ENDPOINT"
echo

## Main loop: random selection between valid, invalid, and misc actions
for i in $(seq 1 $ITERATIONS); do
  r=$((RANDOM % 10))

  if [ "$r" -le 5 ]; then
    ## majority chance -> valid request
    idx=$((RANDOM % ${#valid_payloads[@]}))
    payload="${valid_payloads[$idx]}"
    send_post "$payload"
  elif [ "$r" -le 7 ]; then
    ## some invalid payloads
    idx=$((RANDOM % ${#invalid_payloads[@]}))
    payload="${invalid_payloads[$idx]}"
    send_post "$payload"
  else
    ## misc requests: wrong endpoint or wrong method
    if [ $((RANDOM % 2)) -eq 0 ]; then
      ## wrong endpoint -> expect 404
      send_post '{"place":1}' "$(echo)" >/dev/null 2>&1 || true
      ## actually call a non-existing endpoint with a short payload
      send_post_to_wrong() {
        http_code=$(curl -s -o /tmp/last_response_body.txt -w "%{http_code}" -X POST "$API_URL/predicttt/" -H "Content-Type: application/json" -d '{"place":1,"catu":1}' || true)
        echo "POST $API_URL/predicttt/ -> ${http_code}"
        head -c 300 /tmp/last_response_body.txt | sed -n '1,3p'
        echo
      }
      send_post_to_wrong
    else
      ## GET to /predict/ -> expect 405 Method Not Allowed
      send_get "$PREDICT_ENDPOINT"
    fi
  fi

  ## small sleep to avoid overwhelming the service too much
  sleep "$SLEEP_BETWEEN"
done

echo
echo "Mixed load finished. Fetching metrics snapshot..."
echo

## Print relevant metrics lines for quick inspection
curl -s "$PROMETHEUS_METRICS" | egrep "^(api_predict_total|inference_time_seconds|http_requests_total|http_request_duration_seconds)" -n || true

echo
echo "If you want to query Prometheus directly, you can run:"
echo "  curl 'http://localhost:9090/api/v1/query?query=api_predict_total'"
echo "  curl 'http://localhost:9090/api/v1/query?query=inference_time_seconds_count'"
echo

