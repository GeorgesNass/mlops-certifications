'''
__author__ = "Georges Nassopoulos"
__contributors__ = "Mateo Villa Arias"
__copyright__ = None
__version__ = "1.0.0"
__email__ = "georges.nassopoulos@gmail.com"
__status__ = "Dev"
__desc__ = Global constants for live data collection and model pipeline
'''

## Import core libraries
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import numpy as np
import joblib

## Import Prometheus monitoring tools
from prometheus_fastapi_instrumentator import Instrumentator
from prometheus_client import Summary, Counter

## Initialize FastAPI application
app = FastAPI()

## Expose default instrumentation metrics (HTTP requests, latency, etc.)
Instrumentator().instrument(app).expose(app)

## Define the Accident input model using Pydantic
class Accident(BaseModel):
    place: int
    catu: int
    sexe: int
    secu1: float
    year_acc: int
    victim_age: int
    catv: int
    obsm: int
    motor: int
    catr: int
    circ: int
    surf: int
    situ: int
    vma: int
    jour: int
    mois: int
    lum: int
    dep: int
    com: int
    agg_: int
    int_: int
    atm: int
    col: int
    lat: float
    long: float
    hour: int
    nb_victim: int
    nb_vehicules: int


##########################################
## Load the trained model
## The model was created in step 1 and saved as "trained_model.joblib"
##########################################
model = joblib.load("../../models/trained_model.joblib")

##########################################
## Define Prometheus metrics
##########################################

## Summary: to measure inference time duration
inference_time_summary = Summary(
    'inference_time_seconds',
    'Time taken for inference'
)

## Counter: to count the total number of prediction requests
prediction_counter = Counter(
    'api_predict_total',
    'Total number of prediction requests'
)


##########################################
## Endpoint for predicting accident severity
##########################################
@app.post("/predict/")
def predict_grav(accident: Accident):
    """
    Predict the severity of an accident based on input features.
    """

    ## Increment prediction counter for each request (valid or invalid)
    prediction_counter.inc()

    ## Build the feature vector from incoming request
    features = np.array([
        accident.place, accident.catu, accident.sexe, accident.secu1, accident.year_acc,
        accident.victim_age, accident.catv, accident.obsm, accident.motor, accident.catr,
        accident.circ, accident.surf, accident.situ, accident.vma, accident.jour, accident.mois,
        accident.lum, accident.dep, accident.com, accident.agg_, accident.int_, accident.atm,
        accident.col, accident.lat, accident.long, accident.hour,
        accident.nb_victim, accident.nb_vehicules
    ])

    ## Reshape to fit model input format (1 sample, n features)
    features = features.reshape(1, -1)

    ## Measure inference time using Prometheus Summary
    with inference_time_summary.time():
        prediction = model.predict(features)

    ## Return the model prediction as JSON response
    return {"prediction": int(prediction)}


##########################################
## Root endpoint
##########################################
@app.get("/", response_class=HTMLResponse)
def root():
    """
    Root endpoint displaying a welcome message.
    """
    return """
    <html>
    <body>
        <h1>Welcome to the Accident Severity Prediction API</h1>
    </body>
    </html>
    """

