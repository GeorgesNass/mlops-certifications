# 📄 README — Monitoring a Machine Learning Model with FastAPI, Prometheus, and Grafana  

---

## Project Overview  
This project demonstrates how to deploy and monitor a **machine learning model (RandomForest)** exposed via **FastAPI**.  
The monitoring stack is based on:  
- **Prometheus** → collects API and inference metrics.  
- **Grafana** → visualizes the metrics in dashboards.  

---

## Requirements  
- **Python**: 3.9+  
- **Docker**: 24+  
- **Docker Compose**: v2.20+  

---

## How to Run the Project  

⚠️ **This section follows the exam instructions exactly.**  

### Prerequest : Data science/ML commandes  
```bash
## Step 1 – Clone the provided repository
git clone https://github.com/DataScientest-Studio/Template_MLOps_accidents.git

## Step 2 – Move into the project and checkout the correct branch
cd Template_MLOps_accidents
git checkout notebook_8_prometheus_mlops

## Step 3 – Create a Python virtual environment
virtualenv my_env

## Step 4 – Activate the virtual environment
source my_env/bin/activate

## Step 5 – Install dependencies
pip install -r ./requirements.txt

## Step 6 – Import raw data
python3 ./src/data/import_raw_data.py

## Step 7 – Run preprocessing (input: ./data/raw → output: ./data/preprocessed)
python3 ./src/data/make_dataset.py

## Step 8 – Train the Random Forest model
python3 ./src/models/train_model.py

## Step 9 – Verify that the trained model has been saved (model.joblib)
ls -lh models/

```

### Prometheus configuration  
The file `prometheus.yml` was already provided in the cloned repository.  
Content:  

```yaml
# config file for prometheus
global:
  scrape_interval: 10s
  scrape_timeout: 10s
  evaluation_interval: 10s

scrape_configs:
- job_name: prometheus
  static_configs:
    - targets: ['localhost:9090']

- job_name: 'fastapi'
  scrape_interval: 10s
  metrics_path: /metrics
  static_configs:
    - targets: ['web:8000']
```

👉 This configuration makes Prometheus scrape both itself (`localhost:9090`) and the FastAPI API (`web:8000`).  

### Docker Compose configuration  
The repository also already includes the `docker-compose.yml`:  

```yaml
version: "3.8"

volumes:
    prometheus_data: {}
    grafana_data: {}

services:
  web:
    build: .
    command: uvicorn src.api.app:app --reload --workers 1 --host 0.0.0.0 --port 8000
    volumes:
      - ./src/:/usr/src/api/
    container_name: api_template_accidents
    ports:
      - "8000:8000"

  prometheus:
    image: prom/prometheus
    container_name: prometheus_template_accidents
    ports:
      - 9090:9090
    volumes:
      - ./prometheus_data/prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'

  grafana:
    image: grafana/grafana
    container_name: grafana_template_accidents
    ports:
      - 3000:3000
    volumes:
      - grafana_data:/var/lib/grafana
```

👉 This launches three services: FastAPI (`web`), Prometheus, and Grafana.  

### Run in background  
Instead of running in the foreground, you can start in **detached mode**:  

```bash
docker-compose up -d --build
```

- FastAPI → [http://localhost:8000/docs](http://localhost:8000/docs)  
- Prometheus → [http://localhost:9090](http://localhost:9090)  
- Grafana → [http://localhost:3000](http://localhost:3000)  

---

## NEW FEATURES
### — API Instrumentation  

⚡ **This is a new feature that was added to `app.py`.**  

- Added **Prometheus instrumentation** with the following custom metrics:  
  - `http_requests_total` → count of requests per endpoint and status code.  
  - `inference_time_seconds` → histogram of inference times.  
- Endpoint `/metrics` is now exposed automatically by FastAPI.  
- No need to restart or reconfigure Docker Compose; the API already provides metrics at runtime.  
 
### — Grafana Dashboard  

⚡ **This is a new feature created for this project.**  

#### Steps to load the dashboard  
1. Go to Grafana → [http://localhost:3000](http://localhost:3000).  
2. Login with default credentials: `admin / admin`.  
3. Add Prometheus as a data source → `http://prometheus:9090`.  
4. Import the JSON file provided: `New dashboard-XXXX.json`.  

👉 This will automatically create all panels required by the exam (and more).  

---

## Panels Overview  

| Panel Name                | Description                              | Mandatory? | Formula (PromQL)                                                                 | Type     | Unit        |
|----------------------------|------------------------------------------|------------|-----------------------------------------------------------------------------------|----------|-------------|
| **Total Predictions**      | Count of predictions (success + errors) | ✅ Yes     | `api_predict_total`                                                               | Stat     | count       |
| **Avg Inference Time**     | Average latency over 5–30 min windows   | ✅ Yes     | `rate(inference_time_seconds_sum[30m]) / rate(inference_time_seconds_count[30m])`   | TimeSeries | ms          |
| **Requests/sec by Status** | Breakdown of requests by HTTP code      | ❌ Bonus   | `sum by (status) (rate(http_requests_total[1m]))`                                 | Pie/Bar  | rps         |
| **p95 Latency (5m)**       | 95th percentile latency                 | ❌ Bonus   | `histogram_quantile(0.95, rate(inference_time_seconds_bucket[5m]))`               | TimeSeries | ms          |
| **Error Rate (%)**         | Percentage of failed requests           | ❌ Bonus   | `(sum(rate(http_requests_total{status=~"4..|5.."}[5m])) / sum(rate(http_requests_total[5m]))) * 100` | Stat | %           |

---

## Dashboard Preview  

👉 Here is the final rendered dashboard (to be replaced by your local screenshot):  

```
![Dashboard Preview](./dashboard_preview.png)
```

---

## Testing with Load Script (Optional)  
You can generate artificial traffic with the provided script:  

```bash
./load_test.sh
```

This mixes valid and invalid requests, then prints metrics snapshot.  

---

## Deliverables Summary  
- **FastAPI API code** (`app.py`, instrumented).  
- **docker-compose.yml** (API, Prometheus, Grafana).  
- **prometheus.yml** (scraping config).    
- **Grafana dashboard JSON** (with 2 required + 3 bonus panels).  
- **README.md** (this document + png preview of dashboard).  

---

**Author:** Georges Nassopoulos  
**Email:** georges.nassopoulos@gmail.com  
**Status:** Exam submission  
**License:** No license (educational use only)  
---
