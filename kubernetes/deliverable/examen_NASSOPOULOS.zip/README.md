# 🚀 Kubernetes Project — FastAPI + MySQL (with Docker & DagsHub)

## 📘 Description
This project deploys a **FastAPI** application connected to a **MySQL** database inside a **Kubernetes cluster**.  
The FastAPI app is packaged as a Docker image hosted on Docker Hub:  
**`georgesnassopoulos/k8s-dst-eval-fastapi:latest`**  

It includes deployments, services, environment variables, health probes, and an optional integration test (validated successfully).  
All source code and model artifacts are versioned on **DagsHub** for reproducibility and CI/CD traceability.

---


## 📁 Project Structure

```
│
├── data/                      				## Empty — placeholder for MySQL volume (OK)
│
├── fastapi/                   				## Empty — structural placeholder (OK)
│
├── mysql/
│   ├── mysql-local-data-folder-pv.yaml
│   ├── mysql-service.yaml
│   └── mysql-statefulset.yaml
│
└── test/
    └── k8s-eval-fastapi/
        ├── Dockerfile         				## Builds image → georgesnassopoulos/k8s-dst-eval-fastapi:latest
        ├── fastapi-deployment.yaml
        ├── fastapi-service.yaml
        ├── requirements.txt
        └── app/
            └── main.py
```

---

## 🐳 Docker Image

| **Component** | **Value** |
|----------------|-----------|
| **Image name** | `georgesnassopoulos/k8s-dst-eval-fastapi:latest` |
| **Base image** | `python:3.10-slim` |
| **Entrypoint** | `uvicorn main:app --host 0.0.0.0 --port 8000` |
| **Registry** | [Docker Hub - georgesnassopoulos](https://hub.docker.com/r/georgesnassopoulos/k8s-dst-eval-fastapi) |

---

## ⚙️ Environment Variables

| **Variable** | **Value** | **Description** |
|---------------|------------|----------------|
| `MYSQL_HOST` | `mysql` | MySQL service name |
| `MYSQL_PORT` | `3307` | MySQL service port |
| `MYSQL_USER` | `root` | Database user |
| `MYSQL_PASSWORD` | `RootPass123` | MySQL password |
| `MYSQL_DATABASE` | `mydb` | Database name |

---

## 🏁 Status Summary

| **Component** | **Status** | **Comment** |
|----------------|------------|-------------|
| Namespace | ✅ | `examen-k8s` created |
| MySQL | ✅ | Database `mydb`, port `3307`, password `RootPass123` |
| FastAPI | ✅ | 2 replicas, health probes OK |
| Liveness / Readiness | ✅ | `/docs` and `/tables` return HTTP 200 |
| FastAPI ↔ MySQL Connection | ✅ | Successfully tested |
| [OPTIONAL] Integration Step | 🌟 **PASSED** | `/tables` operational |
| Cluster | ✅ | Fully stable and functional |

---

## 🌟  [OPTIONAL] Step Validated 

> ✅ **Integration test: FastAPI ↔ MySQL**

- Access Swagger UI: `http://localhost:8000/docs`
- Endpoint tested: `GET /tables`
- **Expected result:**
  ```json
  {
    "database": ["test_table"]
  }
  ```
- Confirms correct communication between FastAPI and MySQL within Kubernetes.

---

## 🧪 How to Reproduce and Test

```bash
## 1. Create the namespace for the project
kubectl create namespace examen-k8s

## 2. Deploy MySQL and FastAPI resources
kubectl apply -f mysql/ -n examen-k8s
kubectl apply -f test/k8s-eval-fastapi/ -n examen-k8s

## 3. Check pods status
kubectl get pods -n examen-k8s

## 4. Verify that both services are created
kubectl get svc -n examen-k8s

## 5. Inspect FastAPI logs to confirm MySQL connection
kubectl logs -n examen-k8s -l app=fastapi

## 6. Forward port to access FastAPI locally
kubectl port-forward svc/fastapi-service -n examen-k8s 8000:8000

## 7. Open Swagger UI
# → http://localhost:8000/docs

## 8. Test FastAPI ↔ MySQL connection
curl http://localhost:8000/tables
# Expected output:
# {"database": ["test_table"]}
```
