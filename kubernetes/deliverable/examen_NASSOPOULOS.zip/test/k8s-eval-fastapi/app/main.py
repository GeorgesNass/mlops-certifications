'''
__author__ = "Georges Nassopoulos"
__copyright__ = None
__version__ = "1.0.0"
__email__ = "georges.nassopoulos@gmail.com"
__status__ = "Dev"
__desc__ = "FastAPI service to manage dynamic MySQL tables using SQLAlchemy within a Kubernetes environment."
'''

## Import required libraries
from fastapi import FastAPI
from pydantic import BaseModel
from sqlalchemy import create_engine, MetaData, text, Column, Table, Integer, String
from sqlalchemy.exc import SQLAlchemyError
import os

## Initialize FastAPI app
app = FastAPI()

## Load MySQL environment variables (set in the Kubernetes manifest)
mysql_user = os.getenv("MYSQL_USER", "root")
mysql_password = os.getenv("MYSQL_PASSWORD", "root")
mysql_host = os.getenv("MYSQL_HOST", "mysql")
mysql_port = os.getenv("MYSQL_SERVICE_PORT_MYSQL") or os.getenv("MYSQL_SERVICE_PORT") or os.getenv("MYSQL_PORT", "3307")

## If port contains "tcp://", we keep only the numero
if "tcp://" in mysql_port:
    mysql_port = mysql_port.split(":")[-1]

mysql_database = os.getenv("MYSQL_DATABASE", "airflow_db")

## Print environment variables for debugging purposes
print(os.environ)

## Create SQLAlchemy connection string (using pymysql driver)
conn_string = f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_database}"

## Create the database engine
mysql_engine = create_engine(conn_string)

## Initialize SQLAlchemy metadata object
metadata = MetaData()

## Define the Pydantic model for table schema
class TableSchema(BaseModel):
    table_name: str
    columns: dict

## Define a helper function to parse column types safely
def parse_column_type(type_str: str):
    ## Check for String type with optional length
    if type_str.lower().startswith("string"):
        length = 255
        if "(" in type_str and ")" in type_str:
            length = int(type_str[type_str.find("(")+1:type_str.find(")")])
        return String(length)
    ## Check for Integer type
    elif "int" in type_str.lower():
        return Integer()
    ## Raise an error if the type is unsupported
    else:
        raise ValueError(f"Unsupported type: {type_str}")

## Define endpoint to list existing tables in the database
@app.get("/tables")
async def get_tables():
    ## Execute SQL query to show all tables
    with mysql_engine.connect() as connection:
        results = connection.execute(text('SHOW TABLES;'))
        ## Convert results to dictionary format
        return {"database": [str(r[0]) for r in results.fetchall()]}

## Define endpoint to create a new table dynamically
@app.put("/table")
async def create_table(schema: TableSchema):
    try:
        ## Build SQLAlchemy columns dynamically from input schema
        columns = [Column(col_name, parse_column_type(col_type)) for col_name, col_type in schema.columns.items()]

        ## Create the table, replacing if already existing in metadata
        table = Table(schema.table_name, metadata, *columns, extend_existing=True)

        ## Create table in database (without checking existing)
        metadata.create_all(mysql_engine, tables=[table], checkfirst=False)

        ## Return success message
        return {"message": f"Table '{schema.table_name}' successfully created."}

    ## Handle SQLAlchemy-specific exceptions
    except SQLAlchemyError as e:
        return {"error_msg": str(e)}

    ## Handle unexpected exceptions
    except Exception as e:
        return {"error_msg": f"Unexpected error: {e}"}

